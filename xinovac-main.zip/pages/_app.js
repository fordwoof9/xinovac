import React from 'react';
import 'antd/dist/antd.css';

export default function MyApp({ Component, pageProps }) {
  return <Component {...pageProps} />
}


